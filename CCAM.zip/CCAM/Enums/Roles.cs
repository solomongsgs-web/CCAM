﻿namespace CCAM.Enums
{
    public enum Roles
    {
        Admin,
        Approver,
        User
        // Add more roles as needed
    }
}
